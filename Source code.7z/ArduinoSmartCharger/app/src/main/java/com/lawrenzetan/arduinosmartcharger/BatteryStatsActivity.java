package com.lawrenzetan.arduinosmartcharger;

public class BatteryStatsActivity {
}
