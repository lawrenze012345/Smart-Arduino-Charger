package com.lawrenzetan.arduinosmartcharger;

import android.bluetooth.BluetoothDevice;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.BatteryManager;
import android.os.Bundle;
import android.util.Log;
import android.widget.SeekBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

public class BluetoothActivity extends AppCompatActivity {

    private static final int REQUEST_BLUETOOTH_PERMISSION = 1;

    private SeekBar batteryLevelSeekBar;
    private TextView batteryLevelProgress;
    private TextView selectedBatteryPercentage;
    private TextView temperatureTextView;
    private TextView connectedDeviceTextView;
    private TextView batteryHealthTextView;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Check Bluetooth permissions
        checkBluetoothPermissions();

        // Initialize UI elements
        batteryLevelSeekBar = findViewById(R.id.batteryLevelSeekBar);
        batteryLevelProgress = findViewById(R.id.batteryLevelProgress);
        selectedBatteryPercentage = findViewById(R.id.selectedBatteryPercentage);
        temperatureTextView = findViewById(R.id.temperatureTextView);
        connectedDeviceTextView = findViewById(R.id.connectedDeviceTextView);
        batteryHealthTextView = findViewById(R.id.batteryHealthTextView);

        // Set up SeekBar listener
        batteryLevelSeekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                // Update progress TextView dynamically
                batteryLevelProgress.setText(String.valueOf(progress));
                // Update selected battery percentage TextView
                selectedBatteryPercentage.setText("Selected Battery Percentage: " + progress + "%");
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
                // Do nothing when tracking starts
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                // Do nothing when tracking stops
            }
        });

        // Set initial progress to 90%
        batteryLevelSeekBar.setProgress(90);

        // Register a BroadcastReceiver to listen for battery temperature changes
        registerBatteryTemperatureReceiver();

        // Register a BroadcastReceiver to listen for Bluetooth device changes
        registerBluetoothDeviceReceiver();

        // Register a BroadcastReceiver to listen for battery health changes
        registerBatteryHealthReceiver();
    }

    // Check Bluetooth permissions
    private void checkBluetoothPermissions() {
        if (ActivityCompat.checkSelfPermission(this, android.Manifest.permission.BLUETOOTH_CONNECT) !=
                android.content.pm.PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                    new String[]{android.Manifest.permission.BLUETOOTH_CONNECT},
                    REQUEST_BLUETOOTH_PERMISSION);
        }
    }

    // Handle Bluetooth permission result
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        if (requestCode == REQUEST_BLUETOOTH_PERMISSION) {
            if (grantResults.length > 0 && grantResults[0] == android.content.pm.PackageManager.PERMISSION_GRANTED) {
                // Permission granted
                // Continue with your Bluetooth-related operations
            } else {
                // Permission denied
                // Handle the situation (show a message, disable Bluetooth functionality, etc.)
            }
        }
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
    }

    // BroadcastReceiver to update battery temperature
    private final BroadcastReceiver batteryInfoReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            int temperature = intent.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0);
            // Convert the temperature to Celsius
            double temperatureCelsius = temperature / 10.0;
            // Update the temperature TextView
            temperatureTextView.setText("Battery Temperature: " + temperatureCelsius + "°C");
        }
    };

    // Register the BroadcastReceiver for battery temperature
    private void registerBatteryTemperatureReceiver() {
        IntentFilter filter = new IntentFilter(Intent.ACTION_BATTERY_CHANGED);
        registerReceiver(batteryInfoReceiver, filter);
    }

    // BroadcastReceiver to update connected Bluetooth device name
    private final BroadcastReceiver bluetoothDeviceReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            if (BluetoothDevice.ACTION_FOUND.equals(action)) {
                // A Bluetooth device is found during discovery
                BluetoothDevice device = intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);
                if (device != null) {
                    String deviceName = device.getName();
                    Log.d("BluetoothActivity", "Found Device: " + deviceName);
                    // Update the connected device TextView
                    connectedDeviceTextView.setText("Found Device: " + deviceName);
                }
            } else if (BluetoothDevice.ACTION_ACL_CONNECTED.equals(action)) {
                // A Bluetooth device is connected
                BluetoothDevice device = intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);
                if (device != null) {
                    String deviceName = device.getName();
                    Log.d("BluetoothActivity", "Connected Device: " + deviceName);
                    // Update the connected device TextView
                    connectedDeviceTextView.setText("Connected Device: " + deviceName);
                }
            } else if (BluetoothDevice.ACTION_ACL_DISCONNECTED.equals(action)) {
                // A Bluetooth device is disconnected
                Log.d("BluetoothActivity", "No Connected Device");
                // Update the connected device TextView (you may clear it or show a default message)
                connectedDeviceTextView.setText("No Connected Device");
            }
        }
    };

    // Register the BroadcastReceiver for Bluetooth device changes
    private void registerBluetoothDeviceReceiver() {
        IntentFilter filter = new IntentFilter();
        filter.addAction(BluetoothDevice.ACTION_FOUND);
        filter.addAction(BluetoothDevice.ACTION_ACL_CONNECTED);
        filter.addAction(BluetoothDevice.ACTION_ACL_DISCONNECTED);
        registerReceiver(bluetoothDeviceReceiver, filter);
    }

    // BroadcastReceiver to update battery health
    private final BroadcastReceiver batteryHealthReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            int health = intent.getIntExtra(BatteryManager.EXTRA_HEALTH, BatteryManager.BATTERY_HEALTH_UNKNOWN);

            String healthStatus;
            switch (health) {
                case BatteryManager.BATTERY_HEALTH_GOOD:
                    healthStatus = "Good";
                    break;
                case BatteryManager.BATTERY_HEALTH_OVERHEAT:
                    healthStatus = "Overheat";
                    break;
                case BatteryManager.BATTERY_HEALTH_DEAD:
                    healthStatus = "Dead";
                    break;
                case BatteryManager.BATTERY_HEALTH_OVER_VOLTAGE:
                    healthStatus = "Over Voltage";
                    break;
                case BatteryManager.BATTERY_HEALTH_UNSPECIFIED_FAILURE:
                    healthStatus = "Unspecified Failure";
                    break;
                case BatteryManager.BATTERY_HEALTH_COLD:
                    healthStatus = "Cold";
                    break;
                default:
                    healthStatus = "Unknown";
                    break;
            }

            // Update the battery health TextView
            batteryHealthTextView.setText("Battery Health: " + healthStatus);
        }
    };

    // Register the BroadcastReceiver for battery health changes
    private void registerBatteryHealthReceiver() {
        IntentFilter filter = new IntentFilter(Intent.ACTION_BATTERY_CHANGED);
        registerReceiver(batteryHealthReceiver, filter);
    }

    // Unregister the BroadcastReceivers when the activity is destroyed
    @Override
    protected void onDestroy() {
        super.onDestroy();
        unregisterReceiver(batteryInfoReceiver);
        unregisterReceiver(bluetoothDeviceReceiver);
        unregisterReceiver(batteryHealthReceiver);
    }
}
